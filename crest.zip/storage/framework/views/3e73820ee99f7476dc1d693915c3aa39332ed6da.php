<div class="row mb-3 div<?php echo e($temp ?? 1); ?>">
  <label for="title" class="col-md-2 col-form-label text-md-end">Item Title</label>

  <div class="<?php if(isset($temp)): ?> col-md-8 <?php else: ?> col-md-10 <?php endif; ?>">
    <input type="text" class="form-control <?php $__errorArgs = ['t_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="t_title[]" required
      data-parsley-required-message="Please enter item title." data-parsley-maxlength="25"
                  data-parsley-maxlength-message="Title must be of 25 letters or less.">

    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
      <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <?php if(isset($temp)): ?>
  <div class="col-md-2">
    <button class="btn btn-danger btn-sm m-1 btnRemove" data-temp="<?php echo e($temp ?? 1); ?>">Remove</button>
  </div>
  <?php endif; ?>
</div>

<div class="row mb-3">
    <label for="title" class="col-md-2 col-form-label text-md-end">Set Status</label>
  
    <div class="col-md-10">
      <?php $__currentLoopData = \Config::get('Option.item_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <input type="radio" name="t_title_status[]" value="<?php echo e($option); ?>" <?php if($loop->first): ?> checked <?php endif; ?>> <?php echo e($option); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
    </div>
  </div>

<hr><?php /**PATH D:\wamp64\www\crest\resources\views/todo/task.blade.php ENDPATH**/ ?>