

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header bg-success text-white">
          <h5 class="">Create a new To-do List</h5>
        </div>

        <div class="card-body">
          <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

          </div>
          <?php endif; ?>

          <form action="<?php echo e(route('todo.store')); ?>" method="POST" id="todo-create">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
              <label for="title" class="col-md-2 col-form-label text-md-end">Task Title</label>

              <div class="col-md-10">
                <input id="title" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
                  required data-parsley-required-message="Please enter task title." data-parsley-maxlength="25"
                  data-parsley-maxlength-message="Title must be of 25 letters or less.">

                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="row mb-3">
              <label for="title" class="col-md-2 col-form-label text-md-end">Set Status</label>
            
              <div class="col-md-10">
                <?php $__currentLoopData = \Config::get('Option.task_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="radio" class="<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" required
                  data-parsley-required-message="Please select title." value="<?php echo e($option); ?>" <?php if($loop->first): ?> checked <?php endif; ?>> <?php echo e($option); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="row mb-3">
              <label for="title" class="col-md-2 col-form-label text-md-end">Set Proirity</label>
            
              <div class="col-md-10">
                <?php $__currentLoopData = \Config::get('Option.task_priority'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="radio" class="<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="priority" required
                  data-parsley-required-message="Please select title." value="<?php echo e($option); ?>" <?php if($loop->first): ?> checked <?php endif; ?>> <?php echo e($option); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="row">
              <div class="col-md-9">
                <h5>Add Task Items</h5>
              </div>
              <div class="col-md-3">
                <a class="btn btn-primary addTaskItem"><i class="fa-solid fa-plus fa-xl"></i>
                  Add New Item</a>
              </div>
            </div>
            <hr>
            <?php echo $__env->make('todo.task', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="addTaskItemDiv"></div>

            <div class="row mb-0">
              <div class="col-md-12 text-center">
                <button type="submit" name="submit" class="btn btn-primary mr-3">
                  Submit
                </button>
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $('#todo-create').parsley();
  var temp = 1;
  $('.addTaskItem').click(function(){
    temp = temp + 1;
    $.get('<?php echo e(route("task.addblock")); ?>',{'temp':temp},function(data){
      $('.addTaskItemDiv').append(data.view);
    });
  });

  $(document).on('click','.btnRemove',function(){
    $('.div'+$(this).data('temp')).remove();
  });
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\crest\resources\views/todo/create.blade.php ENDPATH**/ ?>