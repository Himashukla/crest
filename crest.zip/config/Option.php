<?php

return [
  'task_status' => array(
    'Active' => 'Active',
    'Skipped' => 'Skipped',
    'Completed' => 'Completed'
  ),

  'task_priority' => array(
    'Low' => 'Low',
    'Normal' => 'Normal',
    'High' => 'High'
  ),

  'item_status' => array(
    'Active' => 'Active',
    'Skipped' => 'Skipped',
    'Completed' => 'Completed'
  ),
];